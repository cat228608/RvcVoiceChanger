import os
import sys
import time
import torch
import torch.nn.functional as F
import torchaudio.transforms as tat
import numpy as np
from noisereduce.torchgate import TorchGate
from pedalboard import (
    Pedalboard,
    Chorus,
    Distortion,
    Reverb,
    PitchShift,
    Limiter,
    Gain,
    Bitcrush,
    Clipping,
    Compressor,
    Delay,
)

now_dir = os.getcwd()
sys.path.append(now_dir)

from rvc.realtime.utils.torch import circular_write, RingBuffer
from rvc.realtime.utils.vad import VADProcessor
from rvc.realtime.pipeline import create_pipeline

SAMPLE_RATE = 16000
AUDIO_SAMPLE_RATE = 48000


def phase_vocoder(a, b, fade_out, fade_in):
    """
    Performs a phase vocoder crossfade between two audio segments.

    This function blends segment `a` and segment `b` by aligning their phases
    in the frequency domain to prevent phase cancellation during the transition,
    while applying the provided fade-out and fade-in windows.

    Args:
        a (torch.Tensor): The first audio segment.
        b (torch.Tensor): The second audio segment.
        fade_out (torch.Tensor): The fade-out window applied to segment `a`.
        fade_in (torch.Tensor): The fade-in window applied to segment `b`.

    Returns:
        torch.Tensor: The crossfaded audio segment.
    """

    # DirectML не поддерживает комплексные тензоры, а фазовый вокодер целиком на
    # них и построен (rfft, abs, angle). На DirectML считаем этот участок на CPU и
    # возвращаем результат на устройство: перекрытие всего ~50 мс, накладные
    # мизерные, зато путь AMD / Intel работает. CUDA-ветка идёт как раньше.
    if str(a.device).startswith("privateuseone"):
        return phase_vocoder(a.cpu(), b.cpu(), fade_out.cpu(), fade_in.cpu()).to(
            a.device
        )

    # Compute the analysis window as the geometric mean of fade curves
    window = (fade_out * fade_in).sqrt()
    # Transform both windowed segments to the frequency domain (Real FFT)
    fa = torch.fft.rfft(a * window)
    fb = torch.fft.rfft(b * window)
    # Calculate the combined magnitude spectrum
    absab = fa.abs() + fb.abs()
    n = a.shape[0]

    # Compensate for the energy of negative frequencies (except DC and Nyquist components)
    if n % 2 == 0:
        absab[1:-1] *= 2
    else:
        absab[1:] *= 2

    # Extract initial phase and calculate the raw phase difference
    phia = fa.angle()
    deltaphase = fb.angle() - phia

    # Reconstruct the signal using a combination of time-domain crossfade
    # and phase-aligned sinusoidal synthesis (Phase Vocoder)
    return (
        a * (fade_out**2)
        + b * (fade_in**2)
        + (
            absab
            * (
                (
                    # Base frequency grid for each bin
                    2 * torch.pi * torch.arange(n // 2 + 1).to(a)
                    +
                    # Phase unwrapping (wrapping delta phase to the [-pi, pi] range)
                    (
                        deltaphase
                        - 2 * torch.pi * (deltaphase / 2 / torch.pi + 0.5).floor()
                    )
                )
                * (torch.arange(n).unsqueeze(-1).to(a) / n)
                + phia  # Continuous phase evolution over time
            ).cos()
        ).sum(-1)
        * window
        / n  # Sum the sinusoidal components (IFFT equivalent) and normalize
    )


class Realtime:
    def __init__(
        self,
        model_path: str = None,
        index_path: str = None,
        f0_method: str = "rmvpe",
        embedder_model: str = None,
        embedder_model_custom: str = None,
        silent_threshold: int = 0,
        vad_enabled: bool = False,
        vad_sensitivity: int = 3,
        vad_frame_ms: int = 30,
        sid: int = 0,
        clean_audio: bool = False,
        clean_strength: float = 0.5,
        post_process: bool = False,
        device: str = None,
        precision: str = "fp32",
        allow_tf32: bool = True,
        torch_compile: bool = False,
        torch_compile_mode: str = "reduce-overhead",
        reduce_gpu_sync: bool = False,
        use_ring_buffer: bool = True,
        volume_gain_mode: str = "interpolated",
        soft_gate: bool = True,
        soft_gate_hangover_ms: float = 200.0,
        soft_gate_attack_ms: float = 15.0,
        soft_gate_release_ms: float = 80.0,
        **kwargs,
    ):
        self.sample_rate = SAMPLE_RATE
        self.convert_buffer = None
        self.pitch_buffer = None
        self.pitchf_buffer = None
        self.return_length = 0
        self.skip_head = 0
        self.silence_front = 0
        # Convert dB to RMS
        self.input_sensitivity = 10 ** (silent_threshold / 20)
        self.window_size = self.sample_rate // 100
        self.kwargs = None
        self.model_path = model_path
        self.index_path = index_path
        self.embedder_model = embedder_model
        self.embedder_model_custom = embedder_model_custom

        # ---------- ускорение ----------
        # Кольцевые буферы создаются в realloc, когда известны размеры.
        self.use_ring_buffer = bool(use_ring_buffer)
        self.reduce_gpu_sync = bool(reduce_gpu_sync)
        self.audio_ring = None
        self.convert_ring = None
        self._cpu_ring = None
        self._cpu_ring_pos = 0
        self.block_frame_16k = 0
        self.block_duration_ms = 0.0

        # ---------- согласование громкости ----------
        self.volume_gain_mode = (
            "interpolated"
            if str(volume_gain_mode).lower() == "interpolated"
            else "block_scalar"
        )
        self._vol_prev = 0.0
        self._gain_ramp = None

        # ---------- soft-gate ----------
        self.soft_gate = bool(soft_gate)
        self.soft_gate_hangover_ms = max(0.0, float(soft_gate_hangover_ms))
        self.soft_gate_attack_ms = max(1.0, float(soft_gate_attack_ms))
        self.soft_gate_release_ms = max(1.0, float(soft_gate_release_ms))
        self._hangover_left_ms = 0.0
        self._gate = 0.0
        self._gate_ramp = None

        self.vad = (
            VADProcessor(
                sensitivity_mode=vad_sensitivity,
                sample_rate=self.sample_rate,
                frame_duration_ms=vad_frame_ms,
            )
            if vad_enabled
            else None
        )
        self.board = self.setup_pedalboard(**kwargs) if post_process else None
        # Create conversion pipelines
        self.pipeline = create_pipeline(
            model_path,
            index_path,
            f0_method,
            embedder_model,
            embedder_model_custom,
            sid,
            device=device,
            precision=precision,
            allow_tf32=allow_tf32,
            torch_compile=torch_compile,
            torch_compile_mode=torch_compile_mode,
        )
        self.device = self.pipeline.device
        self.dtype = self.pipeline.dtype
        # noise reduce
        self.reduced_noise = (
            TorchGate(
                self.pipeline.tgt_sr,
                prop_decrease=clean_strength,
            ).to(self.device)
            if clean_audio
            else None
        )
        # Resampling of inputs and outputs.
        self.resample_in = tat.Resample(
            orig_freq=AUDIO_SAMPLE_RATE, new_freq=self.sample_rate, dtype=torch.float32
        ).to(self.device)
        self.resample_out = tat.Resample(
            orig_freq=self.pipeline.tgt_sr,
            new_freq=AUDIO_SAMPLE_RATE,
            dtype=torch.float32,
        ).to(self.device)

    def setup_pedalboard(self, **kwargs):
        board = Pedalboard()
        if kwargs.get("reverb", False):
            reverb = Reverb(
                room_size=kwargs.get("reverb_room_size", 0.5),
                damping=kwargs.get("reverb_damping", 0.5),
                wet_level=kwargs.get("reverb_wet_level", 0.33),
                dry_level=kwargs.get("reverb_dry_level", 0.4),
                width=kwargs.get("reverb_width", 1.0),
                freeze_mode=kwargs.get("reverb_freeze_mode", 0),
            )
            board.append(reverb)
        if kwargs.get("pitch_shift", False):
            pitch_shift = PitchShift(semitones=kwargs.get("pitch_shift_semitones", 0))
            board.append(pitch_shift)
        if kwargs.get("limiter", False):
            limiter = Limiter(
                threshold_db=kwargs.get("limiter_threshold", -6),
                release_ms=kwargs.get("limiter_release", 0.05),
            )
            board.append(limiter)
        if kwargs.get("gain", False):
            gain = Gain(gain_db=kwargs.get("gain_db", 0))
            board.append(gain)
        if kwargs.get("distortion", False):
            distortion = Distortion(drive_db=kwargs.get("distortion_gain", 25))
            board.append(distortion)
        if kwargs.get("chorus", False):
            chorus = Chorus(
                rate_hz=kwargs.get("chorus_rate", 1.0),
                depth=kwargs.get("chorus_depth", 0.25),
                centre_delay_ms=kwargs.get("chorus_delay", 7),
                feedback=kwargs.get("chorus_feedback", 0.0),
                mix=kwargs.get("chorus_mix", 0.5),
            )
            board.append(chorus)
        if kwargs.get("bitcrush", False):
            bitcrush = Bitcrush(bit_depth=kwargs.get("bitcrush_bit_depth", 8))
            board.append(bitcrush)
        if kwargs.get("clipping", False):
            clipping = Clipping(threshold_db=kwargs.get("clipping_threshold", 0))
            board.append(clipping)
        if kwargs.get("compressor", False):
            compressor = Compressor(
                threshold_db=kwargs.get("compressor_threshold", 0),
                ratio=kwargs.get("compressor_ratio", 1),
                attack_ms=kwargs.get("compressor_attack", 1.0),
                release_ms=kwargs.get("compressor_release", 100),
            )
            board.append(compressor)
        if kwargs.get("delay", False):
            delay = Delay(
                delay_seconds=kwargs.get("delay_seconds", 0.5),
                feedback=kwargs.get("delay_feedback", 0.0),
                mix=kwargs.get("delay_mix", 0.5),
            )
            board.append(delay)

        return board

    def realloc(
        self,
        block_frame: int,
        extra_frame: int,
        crossfade_frame: int,
        sola_search_frame: int,
    ):
        # Calculate frame sizes based on DEVICE sample rate (f.e., 48000Hz) and convert to 16000Hz
        block_frame_16k = int(block_frame / AUDIO_SAMPLE_RATE * self.sample_rate)
        crossfade_frame_16k = int(
            crossfade_frame / AUDIO_SAMPLE_RATE * self.sample_rate
        )
        sola_search_frame_16k = int(
            sola_search_frame / AUDIO_SAMPLE_RATE * self.sample_rate
        )
        extra_frame_16k = int(extra_frame / AUDIO_SAMPLE_RATE * self.sample_rate)

        convert_size_16k = (
            block_frame_16k
            + sola_search_frame_16k
            + extra_frame_16k
            + crossfade_frame_16k
        )
        if (
            modulo := convert_size_16k % self.window_size
        ) != 0:  # Compensate for truncation due to hop size in model output.
            convert_size_16k = convert_size_16k + (self.window_size - modulo)
        self.convert_feature_size_16k = convert_size_16k // self.window_size

        self.block_frame_16k = block_frame_16k
        self.skip_head = extra_frame_16k // self.window_size
        self.return_length = self.convert_feature_size_16k - self.skip_head
        self.silence_front = (
            extra_frame_16k - (self.window_size * 5) if self.silence_front else 0
        )
        # Number of blocks to fill convert_buffer before enabling model output.
        self.warmup_blocks = int(np.ceil(convert_size_16k / block_frame_16k)) + 1
        # Длительность блока нужна soft-gate: все его времена заданы в мс.
        self.block_duration_ms = block_frame * 1000.0 / AUDIO_SAMPLE_RATE

        # Audio buffer to measure volume between chunks
        audio_buffer_size = block_frame_16k + crossfade_frame_16k

        if self.use_ring_buffer:
            # Настоящее кольцо с индексом: вместо сдвига всего буфера с
            # аллокацией клона каждый блок — две copy_ по длине блока.
            self.audio_ring = RingBuffer(
                audio_buffer_size, dtype=self.dtype, device=self.device
            )
            self.convert_ring = RingBuffer(
                convert_size_16k, dtype=self.dtype, device=self.device
            )
            self.audio_buffer = self.audio_ring.window()
            self.convert_buffer = self.convert_ring.window()
        else:
            # Режим совместимости: старый circular_write.
            self.audio_ring = None
            self.convert_ring = None
            self.audio_buffer = torch.zeros(
                audio_buffer_size, dtype=self.dtype, device=self.device
            )
            # Audio buffer for conversion without silence
            self.convert_buffer = torch.zeros(
                convert_size_16k, dtype=self.dtype, device=self.device
            )

        # CPU-копия кольца громкости для режима без лишних синков.
        self._cpu_ring = np.zeros(audio_buffer_size, dtype=np.float32)
        self._cpu_ring_pos = 0
        # Additional +1 is to compensate for pitch extraction algorithm
        # that can output additional feature.
        self.pitch_buffer = torch.zeros(
            self.convert_feature_size_16k + 1, dtype=torch.int64, device=self.device
        )
        self.pitchf_buffer = torch.zeros(
            self.convert_feature_size_16k + 1, dtype=self.dtype, device=self.device
        )

    # ------------------------------------------------------------------
    # Запись в буферы: кольцо с индексом или legacy circular_write
    # ------------------------------------------------------------------

    def _write_audio_buffer(self, audio_input_16k: torch.Tensor) -> torch.Tensor:
        """Дописывает блок в буфер измерения громкости.

        В кольцевом режиме двигается только индекс записи, поэтому окно
        надо перечитывать после каждой записи — его смещение меняется.
        """
        if self.audio_ring is not None:
            self.audio_buffer = self.audio_ring.write(audio_input_16k)
        else:
            circular_write(audio_input_16k, self.audio_buffer)
        return self.audio_buffer

    def _write_convert_buffer(self, audio_input_16k: torch.Tensor) -> torch.Tensor:
        """Дописывает блок в буфер контекста для конвертации."""
        if self.convert_ring is not None:
            self.convert_buffer = self.convert_ring.write(audio_input_16k)
        else:
            circular_write(audio_input_16k, self.convert_buffer)
        return self.convert_buffer

    # ------------------------------------------------------------------
    # CPU-сторона: RMS и VAD без синхронизации GPU -> CPU
    # ------------------------------------------------------------------

    def _cpu_downsample_16k(self, audio_input: np.ndarray) -> np.ndarray:
        """Грубая децимация 48k -> 16k усреднением по 3 семпла.

        Точный полифазный ресемплер живёт на GPU, и тянуть его результат
        обратно на CPU — это лишняя синхронизация на каждом блоке.
        Для оценки громкости и для webrtcvad box-фильтра более чем достаточно.
        """
        x = np.asarray(audio_input, dtype=np.float32).reshape(-1)
        target = int(self.block_frame_16k) or max(1, x.shape[0] // 3)
        usable = (x.shape[0] // 3) * 3

        if usable:
            y = x[:usable].reshape(-1, 3).mean(axis=1)
        else:
            y = np.zeros(0, dtype=np.float32)

        if y.shape[0] == target:
            return y
        if y.shape[0] > target:
            return y[-target:]

        out = np.zeros(target, dtype=np.float32)
        if y.shape[0]:
            out[-y.shape[0] :] = y
        return out

    def _cpu_volume(self, block_16k: np.ndarray) -> float:
        """RMS по CPU-кольцу той же длины, что audio_buffer. Нуль GPU-синков."""
        ring = self._cpu_ring
        if ring is None or ring.shape[0] == 0:
            if block_16k.shape[0] == 0:
                return 0.0
            return float(np.sqrt(np.mean(np.square(block_16k))))

        n = min(int(block_16k.shape[0]), int(ring.shape[0]))
        if n > 0:
            pos = int(self._cpu_ring_pos)
            head = min(n, ring.shape[0] - pos)
            ring[pos : pos + head] = block_16k[:head]
            rest = n - head
            if rest > 0:
                ring[:rest] = block_16k[head:n]
            self._cpu_ring_pos = (pos + n) % ring.shape[0]

        return float(np.sqrt(np.mean(np.square(ring))))

    def _vad_frame(
        self, audio_input: np.ndarray, audio_input_16k: torch.Tensor
    ) -> np.ndarray:
        """Кадр 16 кГц для webrtcvad.

        При reduce_gpu_sync берём CPU-децимацию (без синка), иначе — прежний
        путь через .cpu(). Вызов .float() обязателен: при fp16/bf16 буфер уже
        не float32, и webrtcvad получил бы мусор.
        """
        if self.reduce_gpu_sync:
            return self._cpu_downsample_16k(audio_input)
        return audio_input_16k.detach().float().cpu().numpy().copy()

    # ------------------------------------------------------------------
    # Согласование громкости и soft-gate
    # ------------------------------------------------------------------

    def _output_ramp(self, length: int, attr: str) -> torch.Tensor:
        """Кэшированный линейный рамп 0..1 нужной длины."""
        ramp = getattr(self, attr, None)
        if ramp is None or int(ramp.shape[0]) != int(length):
            ramp = torch.linspace(
                0.0,
                1.0,
                steps=int(length),
                device=self.device,
                dtype=torch.float32,
            )
            setattr(self, attr, ramp)
        return ramp

    def _apply_output_gain(
        self, audio_model: torch.Tensor, vol_t: torch.Tensor, vol: float
    ) -> torch.Tensor:
        """Согласование громкости выхода с громкостью входа.

        block_scalar (старый код): умножение на скаляр RMS всего буфера.
        Скаляр меняется СТУПЕНЬКОЙ на границе блока: при блоке 128 мс это
        амплитудная модуляция ~7.8 Гц — то самое дрожание/тремоло.

        interpolated (новый): ли����ейный рамп от громкости предыдущего блока к
        текущей по всей длине блока — ступеньки нет, модуляции нет.
        """
        if self.volume_gain_mode != "interpolated":
            self._vol_prev = float(vol)
            return audio_model * vol_t

        ramp = self._output_ramp(int(audio_model.shape[0]), "_gain_ramp")
        vol_prev = float(self._vol_prev)
        gain = vol_prev + (float(vol) - vol_prev) * ramp
        self._vol_prev = float(vol)
        return audio_model * gain.to(audio_model.dtype)

    def _update_gate(self, is_speech: bool):
        """Soft-gate с hangover и раздельными attack/release.

        Возвращает (gate_start, gate_end, fully_closed). Значение гейта меняется
        не скачком, а рампом по длине блока, поэтому фаза не рвётся и не
        возникает щёлчка на каждом входе/выходе из речи.
        """
        block_ms = float(self.block_duration_ms) or 1.0

        if is_speech:
            self._hangover_left_ms = float(self.soft_gate_hangover_ms)
        else:
            self._hangover_left_ms = max(0.0, float(self._hangover_left_ms) - block_ms)

        target = 1.0 if (is_speech or self._hangover_left_ms > 0.0) else 0.0

        gate_start = float(self._gate)
        if target > gate_start:
            gate_end = min(target, gate_start + block_ms / float(self.soft_gate_attack_ms))
        elif target < gate_start:
            gate_end = max(
                target, gate_start - block_ms / float(self.soft_gate_release_ms)
            )
        else:
            gate_end = target

        self._gate = gate_end
        return gate_start, gate_end, (gate_start <= 1e-6 and gate_end <= 1e-6)

    def _convert(
        self,
        f0_up_key,
        index_rate,
        protect,
        volume_envelope,
        f0_autotune,
        f0_autotune_strength,
        proposed_pitch,
        proposed_pitch_threshold,
    ):
        return self.pipeline.voice_conversion(
            self.convert_buffer,
            self.pitch_buffer,
            self.pitchf_buffer,
            f0_up_key,
            index_rate,
            self.convert_feature_size_16k,
            self.silence_front,
            self.skip_head,
            self.return_length,
            protect,
            volume_envelope,
            f0_autotune,
            f0_autotune_strength,
            proposed_pitch,
            proposed_pitch_threshold,
            self.reduced_noise,
            self.board,
            block_size_16k=self.block_frame_16k,
        )

    def inference(
        self,
        audio_input: np.ndarray,
        f0_up_key: int = 0,
        index_rate: float = 0.5,
        protect: float = 0.5,
        volume_envelope: float = 1,
        f0_autotune: bool = False,
        f0_autotune_strength: float = 1,
        proposed_pitch: bool = False,
        proposed_pitch_threshold: float = 155.0,
    ):
        if self.pipeline is None:
            raise RuntimeError("Pipeline is not initialized.")

        runner = self._inference_soft if self.soft_gate else self._inference_legacy
        return runner(
            audio_input,
            f0_up_key,
            index_rate,
            protect,
            volume_envelope,
            f0_autotune,
            f0_autotune_strength,
            proposed_pitch,
            proposed_pitch_threshold,
        )

    def _inference_soft(
        self,
        audio_input: np.ndarray,
        f0_up_key: int = 0,
        index_rate: float = 0.5,
        protect: float = 0.5,
        volume_envelope: float = 1,
        f0_autotune: bool = False,
        f0_autotune_strength: float = 1,
        proposed_pitch: bool = False,
        proposed_pitch_threshold: float = 155.0,
    ):
        """Новая архитектура: единый путь без веток с ровными нулями."""
        # Input audio is always float32
        audio_input_16k = self.resample_in(
            torch.as_tensor(audio_input, dtype=torch.float32, device=self.device)
        ).to(self.dtype)

        self._write_audio_buffer(audio_input_16k)
        vol_t = torch.sqrt(torch.square(self.audio_buffer).mean())

        if self.reduce_gpu_sync:
            block_16k_cpu = self._cpu_downsample_16k(audio_input)
            vol = max(self._cpu_volume(block_16k_cpu), 0.0)
        else:
            block_16k_cpu = None
            vol = max(vol_t.item(), 0.0)

        # Буфер контекста пишем ВСЕГДА. Старый код в ветках тишины его не
        # обновлял, поэтому после паузы модель видела устаревший контекст
        # и первый слог выходил «жёваным».
        self._write_convert_buffer(audio_input_16k)

        warming = self.warmup_blocks > 0
        if warming:
            self.warmup_blocks -= 1

        is_speech = vol >= self.input_sensitivity
        if is_speech and self.vad is not None:
            if block_16k_cpu is None:
                block_16k_cpu = self._vad_frame(audio_input, audio_input_16k)
            is_speech = bool(self.vad.is_speech(block_16k_cpu))

        gate_start, gate_end, fully_closed = self._update_gate(is_speech and not warming)

        # Пайплайн гоняем всегда: так же, как и в старом коде, но теперь
        # контекст актуален, и при открытии гейта голос не начинается с нуля.
        audio_model = self._convert(
            f0_up_key,
            index_rate,
            protect,
            volume_envelope,
            f0_autotune,
            f0_autotune_strength,
            proposed_pitch,
            proposed_pitch_threshold,
        )

        if warming or fully_closed:
            # Гейт закрыт полностью: отдаём тишину, но фазу не рвём —
            # process_audio затухает sola_buffer окном, а не зануляет его.
            return (
                torch.zeros(
                    audio_model.shape, dtype=torch.float32, device=self.device
                ),
                vol,
                True,
            )

        audio_out: torch.Tensor = self.resample_out(
            self._apply_output_gain(audio_model, vol_t, vol)
        )

        if gate_start < 1.0 or gate_end < 1.0:
            ramp = self._output_ramp(int(audio_out.shape[0]), "_gate_ramp")
            audio_out = audio_out * (gate_start + (gate_end - gate_start) * ramp)

        return audio_out, vol, False

    def _inference_legacy(
        self,
        audio_input: np.ndarray,
        f0_up_key: int = 0,
        index_rate: float = 0.5,
        protect: float = 0.5,
        volume_envelope: float = 1,
        f0_autotune: bool = False,
        f0_autotune_strength: float = 1,
        proposed_pitch: bool = False,
        proposed_pitch_threshold: float = 155.0,
    ):
        """Старая архитектура: три ветки с жёсткими нулями на выходе."""
        # Input audio is always float32
        audio_input_16k = self.resample_in(
            torch.as_tensor(audio_input, dtype=torch.float32, device=self.device)
        ).to(self.dtype)
        self._write_audio_buffer(audio_input_16k)

        vol_t = torch.sqrt(torch.square(self.audio_buffer).mean())
        if self.reduce_gpu_sync:
            vol = max(self._cpu_volume(self._cpu_downsample_16k(audio_input)), 0.0)
        else:
            vol = max(vol_t.item(), 0)

        board = self.board
        reduced_noise = self.reduced_noise

        # Fill convert_buffer with real audio, output zeros during warmup.
        if self.warmup_blocks > 0:
            self.warmup_blocks -= 1
            self._write_convert_buffer(audio_input_16k)
            audio_model = self.pipeline.voice_conversion(
                self.convert_buffer,
                self.pitch_buffer,
                self.pitchf_buffer,
                f0_up_key,
                index_rate,
                self.convert_feature_size_16k,
                self.silence_front,
                self.skip_head,
                self.return_length,
                protect,
                volume_envelope,
                f0_autotune,
                f0_autotune_strength,
                proposed_pitch,
                proposed_pitch_threshold,
                reduced_noise,
                board,
                block_size_16k=self.block_frame_16k,
            )
            return (
                torch.zeros(audio_model.shape, dtype=torch.float32, device=self.device),
                vol,
                True,
            )

        if self.vad is not None:
            is_speech = self.vad.is_speech(self._vad_frame(audio_input, audio_input_16k))
            if not is_speech:
                # Busy wait to keep power manager happy and clocks stable. Running pipeline on-demand seems to lag when the delay between
                # voice changer activation is too high.
                # https://forums.developer.nvidia.com/t/why-kernel-calculate-speed-got-slower-after-waiting-for-a-while/221059/9
                audio_model = self.pipeline.voice_conversion(
                    self.convert_buffer,
                    self.pitch_buffer,
                    self.pitchf_buffer,
                    f0_up_key,
                    index_rate,
                    self.convert_feature_size_16k,
                    self.silence_front,
                    self.skip_head,
                    self.return_length,
                    protect,
                    volume_envelope,
                    f0_autotune,
                    f0_autotune_strength,
                    proposed_pitch,
                    proposed_pitch_threshold,
                    reduced_noise,
                    board,
                    block_size_16k=self.block_frame_16k,
                )

                return (
                    torch.zeros(
                        audio_model.shape, dtype=torch.float32, device=self.device
                    ),
                    vol,
                    True,
                )

        if vol < self.input_sensitivity:
            audio_model = self.pipeline.voice_conversion(
                self.convert_buffer,
                self.pitch_buffer,
                self.pitchf_buffer,
                f0_up_key,
                index_rate,
                self.convert_feature_size_16k,
                self.silence_front,
                self.skip_head,
                self.return_length,
                protect,
                volume_envelope,
                f0_autotune,
                f0_autotune_strength,
                proposed_pitch,
                proposed_pitch_threshold,
                reduced_noise,
                board,
                block_size_16k=self.block_frame_16k,
            )

            return (
                torch.zeros(audio_model.shape, dtype=torch.float32, device=self.device),
                vol,
                True,
            )

        self._write_convert_buffer(audio_input_16k)

        audio_model = self.pipeline.voice_conversion(
            self.convert_buffer,
            self.pitch_buffer,
            self.pitchf_buffer,
            f0_up_key,
            index_rate,
            self.convert_feature_size_16k,
            self.silence_front,
            self.skip_head,
            self.return_length,
            protect,
            volume_envelope,
            f0_autotune,
            f0_autotune_strength,
            proposed_pitch,
            proposed_pitch_threshold,
            reduced_noise,
            board,
            block_size_16k=self.block_frame_16k,
        )

        # Scale output by the current input RMS to suppress residue during silence.
        # Переключатель: старый ступенчатый скаляр или интерполированная
        # огибающая (см. _apply_output_gain).
        audio_out: torch.Tensor = self.resample_out(
            self._apply_output_gain(audio_model, vol_t, vol)
        )
        return audio_out, vol, False

    def __del__(self):
        del self.pipeline


class VoiceChanger:
    def __init__(
        self,
        read_chunk_size: int,
        cross_fade_overlap_size: float,
        extra_convert_size: float,
        model_path: str = None,
        index_path: str = None,
        f0_method: str = "rmvpe",
        embedder_model: str = None,
        embedder_model_custom: str = None,
        silent_threshold: int = 0,
        vad_enabled: bool = False,
        vad_sensitivity: int = 3,
        vad_frame_ms: int = 30,
        sid: int = 0,
        clean_audio: bool = False,
        clean_strength: float = 0.5,
        post_process: bool = False,
        record_audio: bool = False,
        record_audio_path: str = None,
        export_format: str = "WAV",
        device: str = None,
        **kwargs,
    ):
        self.soundfile = None
        self.record_audio = record_audio
        self.record_audio_path = record_audio_path
        self.export_format = export_format
        self.block_frame = read_chunk_size * 128
        self.crossfade_frame = int(cross_fade_overlap_size * AUDIO_SAMPLE_RATE)
        self.extra_frame = int(extra_convert_size * AUDIO_SAMPLE_RATE)
        self.sola_search_frame = AUDIO_SAMPLE_RATE // 100
        self.sola_buffer = None
        self.vc_model = Realtime(
            model_path,
            index_path,
            f0_method,
            embedder_model,
            embedder_model_custom,
            silent_threshold,
            vad_enabled,
            vad_sensitivity,
            vad_frame_ms,
            sid,
            clean_audio,
            clean_strength,
            post_process,
            device=device,
            **kwargs,
        )
        self.device = self.vc_model.device
        self.vc_model.realloc(
            self.block_frame,
            self.extra_frame,
            self.crossfade_frame,
            self.sola_search_frame,
        )
        self.generate_strength()
        self.setup_soundfile_record()

    def generate_strength(self):
        self.fade_in_window: torch.Tensor = (
            torch.sin(
                0.5
                * np.pi
                * torch.linspace(
                    0.0,
                    1.0,
                    steps=self.crossfade_frame,
                    device=self.device,
                    dtype=torch.float32,
                )
            )
            ** 2
        )

        self.fade_out_window: torch.Tensor = 1 - self.fade_in_window
        self.sola_denominator_kernel = torch.ones(
            1, 1, self.crossfade_frame, device=self.device, dtype=torch.float32
        )
        # The size will change from the previous result, so the record will be deleted.
        self.sola_buffer = torch.zeros(
            self.crossfade_frame, device=self.device, dtype=torch.float32
        )

        # Окно затухания sola_buffer в тишине при soft-gate: та же sin²-кривая,
        # что у кроссфейда, плюс общий множитель 0.5, чтобы затухание
        # накапливалось от блока к блоку (иначе первый семпл буфера,
        # где fade_out == 1.0, никогда бы не спадал).
        self.sola_release_window: torch.Tensor = self.fade_out_window * 0.5

        # Флаг вместо sola_buffer.any(): убирает синк GPU->CPU на каждом блоке.
        self._sola_is_silent = True
        # Закреплённый (pinned) буфер для переноса выхода GPU->CPU.
        self._out_pinned = None

    def _download_output(self, tensor: torch.Tensor, block_size: int) -> np.ndarray:
        """Перенос готового блока GPU -> CPU.

        При reduce_gpu_sync используем pinned-буфер и non_blocking-копию с одним
        явным ожиданием потока: это единственный оставшийся синк за блок
        (RMS и VAD считаются на CPU, `.any()` заменён флагом).
        """
        flat = tensor.detach().float()

        if not getattr(self.vc_model, "reduce_gpu_sync", False) or not str(
            self.device
        ).startswith("cuda"):
            return flat.cpu().numpy()

        if self._out_pinned is None or int(self._out_pinned.shape[0]) != int(
            block_size
        ):
            try:
                self._out_pinned = torch.empty(
                    int(block_size), dtype=torch.float32, pin_memory=True
                )
            except Exception as error:
                print(f"[Warning]: pinned buffer is unavailable: {error}")
                self._out_pinned = None
                return flat.cpu().numpy()

        self._out_pinned.copy_(flat, non_blocking=True)
        torch.cuda.current_stream(self.device).synchronize()
        return self._out_pinned.numpy().copy()

    def setup_soundfile_record(self):
        import soundfile as sf

        self.soundfile = (
            sf.SoundFile(
                self.record_audio_path,
                mode="w",
                samplerate=AUDIO_SAMPLE_RATE,
                channels=1,
                format=self.export_format.lower(),
            )
            if self.record_audio
            else None
        )

    def process_audio(
        self,
        audio_input: np.ndarray,
        f0_up_key: int = 0,
        index_rate: float = 0.5,
        protect: float = 0.5,
        volume_envelope: float = 1,
        f0_autotune: bool = False,
        f0_autotune_strength: float = 1,
        proposed_pitch: bool = False,
        proposed_pitch_threshold: float = 155.0,
        use_phase_vocoder: bool = True,
    ):
        block_size = audio_input.shape[0]

        audio, vol, is_silence = self.vc_model.inference(
            audio_input,
            f0_up_key,
            index_rate,
            protect,
            volume_envelope,
            f0_autotune,
            f0_autotune_strength,
            proposed_pitch,
            proposed_pitch_threshold,
        )

        if is_silence:
            if getattr(self.vc_model, "soft_gate", False):
                # Не занулять: резкий сброс рвёт фазу и даёт щёлчок на
                # каждом входе/выходе из речи. Затухаем окном.
                self.sola_buffer.mul_(self.sola_release_window)
            else:
                # Clear sola_buffer and return zeros for silent input.
                self.sola_buffer.zero_()
            self._sola_is_silent = True
            silence_output = np.zeros(block_size, dtype=np.float32)
            if self.record_audio and self.soundfile is not None:
                self.soundfile.write(silence_output)
            return silence_output, vol

        # Detect silence-to-speech transition for onset-aware fade-in.
        # `not self.sola_buffer.any()` — это ещё один синк GPU->CPU на каждом
        # блоке. Держим флаг на стороне CPU: семантика та же (буфер
        # сбрасывался только в ветке тишины), но синхронизации нет.
        is_onset = self._sola_is_silent

        conv_input = audio[
            None, None, : self.crossfade_frame + self.sola_search_frame
        ].float()
        cor_nom = F.conv1d(conv_input, self.sola_buffer[None, None, :])
        cor_den = torch.sqrt(
            F.conv1d(conv_input**2, self.sola_denominator_kernel) + 1e-8
        )
        sola_offset = torch.argmax(cor_nom[0, 0] / cor_den[0, 0])

        audio = audio[sola_offset:]

        if use_phase_vocoder:
            audio[: self.crossfade_frame] = phase_vocoder(
                self.sola_buffer,
                audio[: self.crossfade_frame],
                self.fade_out_window,
                self.fade_in_window,
            )
        else:
            if is_onset:
                # Find voice onset position and apply sin² fade-in, zeroing audio before onset.
                hop = 160  # ~3.3 ms at 48 kHz
                n_hops = block_size // hop
                if n_hops >= 1:
                    hop_energy = (
                        audio[: n_hops * hop]
                        .reshape(n_hops, hop)
                        .abs()
                        .max(dim=1)
                        .values
                    )
                    peak = hop_energy.max().item()
                    onset_sample = 0
                    if peak > 1e-4:
                        above = (hop_energy > 0.1 * peak).nonzero(as_tuple=False)
                        if len(above) > 0:
                            onset_sample = int(above[0].item()) * hop
                else:
                    onset_sample = 0
                audio[:onset_sample] = 0.0
                # Apply sin² fade-in over crossfade_frame duration from onset.
                fade_len = min(block_size - onset_sample, self.crossfade_frame)
                if fade_len > 0:
                    audio[
                        onset_sample : onset_sample + fade_len
                    ] *= self.fade_in_window[:fade_len]
            else:
                audio[: self.crossfade_frame] *= self.fade_in_window
                audio[: self.crossfade_frame] += self.sola_buffer * self.fade_out_window

        # Pad if audio is shorter than block_size + crossfade_frame.
        _need = block_size + self.crossfade_frame
        if audio.shape[0] < _need:
            pad = torch.zeros(
                _need - audio.shape[0], device=audio.device, dtype=audio.dtype
            )
            audio = torch.cat([audio, pad])
        self.sola_buffer[:] = audio[block_size : block_size + self.crossfade_frame]
        self._sola_is_silent = False
        audio_output = self._download_output(audio[:block_size], block_size)

        if self.record_audio and self.soundfile is not None:
            self.soundfile.write(audio_output)

        return audio_output, vol

    @torch.no_grad()
    def on_request(
        self,
        audio_input: np.ndarray,
        f0_up_key: int = 0,
        index_rate: float = 0.5,
        protect: float = 0.5,
        volume_envelope: float = 1,
        f0_autotune: bool = False,
        f0_autotune_strength: float = 1,
        proposed_pitch: bool = False,
        proposed_pitch_threshold: float = 155.0,
        use_phase_vocoder: bool = True,
    ):
        if self.vc_model is None:
            raise RuntimeError("Voice Changer is not selected.")

        start = (
            time.perf_counter()
        )  # Using perf_counter to measure real-time voice conversion latency.
        result, vol = self.process_audio(
            audio_input,
            f0_up_key,
            index_rate,
            protect,
            volume_envelope,
            f0_autotune,
            f0_autotune_strength,
            proposed_pitch,
            proposed_pitch_threshold,
            use_phase_vocoder,
        )
        end = time.perf_counter()

        return result, vol, [0, (end - start) * 1000, 0]
