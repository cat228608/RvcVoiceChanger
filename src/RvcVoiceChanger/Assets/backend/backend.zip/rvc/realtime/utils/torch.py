import os
import faiss
import torch
import torch.nn.functional as F


def circular_write(new_data: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    """
    УСТАРЕВШИЙ путь: сдвигает весь буфер и аллокирует клон на каждый
    буфер на каждом блоке. Оставлен для режима совместимости
    (use_ring_buffer=False). В боевом режиме используется RingBuffer.
    """
    offset = new_data.shape[0]
    target[:-offset] = target[offset:].detach().clone()
    target[-offset:] = new_data
    return target


class RingBuffer:
    """
    Настоящее кольцо с индексом записи вместо сдвига буфера.

    Внутри держится удвоенный буфер длины 2*capacity с инвариантом
    buf[capacity + j] == buf[j]. Благодаря этому любое логическое окно
    «от самого старого к самому свежему» — это обычный contiguous slice,
    то есть view без копирования. На блок приходится две copy_ только
    по длине новых данных, а не по длине всего буфера, и ни одной
    аллокации.
    """

    __slots__ = ("capacity", "_buf", "_w", "_filled")

    def __init__(self, capacity: int, dtype: torch.dtype = torch.float32, device=None):
        self.capacity = int(capacity)
        self._buf = torch.zeros(self.capacity * 2, dtype=dtype, device=device)
        self._w = 0
        self._filled = False

    @property
    def dtype(self):
        return self._buf.dtype

    @property
    def device(self):
        return self._buf.device

    @property
    def filled(self) -> bool:
        """True, как только кольцо хотя бы раз заполнилось целиком."""
        return self._filled

    def write(self, new_data: torch.Tensor) -> torch.Tensor:
        """Дописывает блок и возвращает актуальное окно длины capacity."""
        n = int(new_data.shape[0])
        if n <= 0:
            return self.window()

        cap = self.capacity

        # Блок больше всего кольца: оставляем только хвост.
        if n >= cap:
            tail = new_data[-cap:]
            self._buf[:cap].copy_(tail)
            self._buf[cap:].copy_(tail)
            self._w = 0
            self._filled = True
            return self.window()

        start = self._w
        end = start + n

        if end <= cap:
            self._buf[start:end].copy_(new_data)
            self._buf[cap + start : cap + end].copy_(new_data)
        else:
            first = cap - start
            head = new_data[:first]
            rest = new_data[first:]
            self._buf[start:cap].copy_(head)
            self._buf[cap + start :].copy_(head)
            self._buf[: n - first].copy_(rest)
            self._buf[cap : cap + (n - first)].copy_(rest)

        if end >= cap:
            self._filled = True
        self._w = end % cap
        return self.window()

    def window(self) -> torch.Tensor:
        """Contiguous view на окно от самого старого семпла к самому свежему."""
        return self._buf[self._w : self._w + self.capacity]

    def zero_(self) -> None:
        self._buf.zero_()
        self._w = 0
        self._filled = False


def is_directml(device) -> bool:
    """DirectML-устройство (AMD / Intel Arc): torch называет его privateuseone."""
    return str(device).startswith("privateuseone")


def describe_torch_error(error: BaseException) -> str:
    """Читаемый текст ошибки torch.

    Сообщения из C++-ядра PyTorch отдаёт как есть, а Windows пишет их в
    системной кодировке (cp1251 на русской локали). Python пытается
    разобрать их как UTF-8, падает с UnicodeDecodeError и теряет причину.
    Сырые байты при этом лежат внутри самого исключения — достаём их
    и раскодируем сами.
    """
    if isinstance(error, UnicodeDecodeError):
        raw = getattr(error, "object", b"") or b""
        if isinstance(raw, memoryview):
            raw = raw.tobytes()
        if isinstance(raw, (bytes, bytearray)):
            raw = bytes(raw)
            for encoding in ("cp1251", "cp1252", "utf-8"):
                try:
                    text = raw.decode(encoding)
                except (UnicodeDecodeError, LookupError):
                    continue
                text = " ".join(text.split())
                if text:
                    return text
            return raw.decode("latin-1", "replace")
    return str(error)


# torch.OutOfMemoryError появился только в torch 2.5, а сборка для torch-directml
# закреплена на 2.4.1 — там обращение к нему само бросает AttributeError
# в момент обработки исключения. Собираем список классов тем, что есть.
_OOM_ERRORS = tuple(
    error
    for error in (
        getattr(torch, "OutOfMemoryError", None),
        getattr(getattr(torch, "cuda", None), "OutOfMemoryError", None),
    )
    if isinstance(error, type)
)

# При этих ошибках поиск по индексу уходит на CPU. UnicodeDecodeError в списке
# потому, что DirectML часто отдаёт именно его вместо RuntimeError.
INDEX_SEARCH_ERRORS = _OOM_ERRORS + (
    RuntimeError,
    NotImplementedError,
    UnicodeDecodeError,
)


def empty_device_cache(device=None) -> None:
    """Сбрасывает кэш аллокатора там, где он вообще есть (сегодня — только CUDA).

    На DirectML и CPU аналога empty_cache нет, а безусловный вызов
    torch.cuda.empty_cache() на машине без CUDA может бросить исключение.
    """
    try:
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    except Exception:
        pass


def fft_device(device):
    """Где считать FFT и STFT.

    DirectML не умеет комплексные тензоры, поэтому torch.stft и torch.fft.rfft
    на нём просто падают. Такие участки считаем на CPU и возвращаем на устройство
    уже действительные тензоры: их доля в блоке невелика, а иначе весь путь
    AMD / Intel не работает вообще.
    """
    return torch.device("cpu") if is_directml(device) else device


def resolve_dtype(precision: str, device) -> tuple:
    """
    Подбирает тип тензоров по желанию пользователя и возможностям карты.

    fp16 — Tensor Cores от Volta/Turing (SM 7.0, RTX 20xx),
    bf16 — от Ampere (SM 8.0, RTX 30xx). Недоступные режимы каскадно
    откатываются bf16 -> fp16 -> fp32 с предупреждением в журнал.

    Возвращает (torch.dtype, имя режима).
    """
    requested = str(precision or "fp32").strip().lower()
    device_str = str(device)

    if is_directml(device):
        # DirectML не умеет bf16, а его fp16 реализован не для всех операций:
        # часть свёрток либо падает, либо даёт тишину. Единственный надёжный
        # режим здесь — fp32. На CUDA-ветку это никак не влияет.
        if requested not in ("fp32", "float32", "auto", ""):
            print(
                "[Warning]: %s на DirectML недоступен, работаю в fp32." % requested
            )
        return torch.float32, "fp32"

    if not device_str.startswith("cuda"):
        if requested not in ("fp32", "float32", "auto", ""):
            print(
                "[Warning]: %s доступен только на CUDA, на CPU работаю в fp32."
                % requested
            )
        return torch.float32, "fp32"

    supports_fp16 = False
    supports_bf16 = False
    try:
        major = torch.cuda.get_device_capability(device)[0]
        supports_fp16 = major >= 7
        supports_bf16 = major >= 8 and torch.cuda.is_bf16_supported()
    except Exception:
        pass

    if requested in ("auto", ""):
        if supports_bf16:
            return torch.bfloat16, "bf16"
        if supports_fp16:
            return torch.float16, "fp16"
        return torch.float32, "fp32"

    if requested in ("bf16", "bfloat16"):
        if supports_bf16:
            return torch.bfloat16, "bf16"
        if supports_fp16:
            print("[Warning]: bf16 не поддерживается этой картой, перехожу на fp16.")
            return torch.float16, "fp16"
        print("[Warning]: bf16/fp16 не поддерживаются, остаюсь на fp32.")
        return torch.float32, "fp32"

    if requested in ("fp16", "float16", "half"):
        if supports_fp16:
            return torch.float16, "fp16"
        print("[Warning]: fp16 не поддерживается этой картой, остаюсь на fp32.")
        return torch.float32, "fp32"

    return torch.float32, "fp32"


def apply_backend_flags(device, allow_tf32: bool = True, cudnn_benchmark: bool = True) -> None:
    """
    Глобальные флаги ускорения: TF32 в matmul/cuDNN и автотюнинг cuDNN.

    TF32 даёт ощутимый выигрыш в fp32-режиме на Ampere+ практически без
    потери качества; cudnn.benchmark окупается, так как формы тензоров
    в реалтайме постоянны.
    """
    if not str(device).startswith("cuda"):
        return

    try:
        torch.backends.cuda.matmul.allow_tf32 = bool(allow_tf32)
        torch.backends.cudnn.allow_tf32 = bool(allow_tf32)
    except Exception:
        pass

    try:
        torch.set_float32_matmul_precision("high" if allow_tf32 else "highest")
    except Exception:
        pass

    try:
        torch.backends.cudnn.benchmark = bool(cudnn_benchmark)
    except Exception:
        pass


class CompiledCallable:
    """
    Обёртка над torch.compile с безотказным откатом на eager.

    mode="reduce-overhead" — тот самый режим с CUDA Graphs: вызовы ядер
    записываются в граф и воспроизводятся одним запуском, что срезает
    накладные на маленьких блоках, где GPU больше ждёт CPU, чем считает.

    Важно: CUDA Graphs переиспользуют одну и ту же память вывода, поэтому
    результат клонируется (clone_output=True) — иначе следующий блок
    перезапишет ещё не использованные семплы и будет треск.
    """

    __slots__ = ("_eager", "_compiled", "_mode", "_name", "_clone_output", "failed")

    def __init__(
        self,
        fn,
        enabled: bool = False,
        mode: str = "reduce-overhead",
        name: str = "module",
        clone_output: bool = True,
    ):
        self._eager = fn
        self._compiled = None
        self._mode = mode or "reduce-overhead"
        self._name = name
        self._clone_output = bool(clone_output)
        self.failed = False

        if not enabled:
            return

        if not hasattr(torch, "compile"):
            print(
                "[Warning]: эта сборка PyTorch не умеет torch.compile, работаю без компиляции."
            )
            self.failed = True
            return

        try:
            self._compiled = torch.compile(fn, mode=self._mode, dynamic=False)
            print("[Info]: torch.compile(%s) включён для %s" % (self._mode, name))
        except Exception as error:
            print(
                "[Warning]: torch.compile не удался для %s (%s), работаю без компиляции."
                % (name, error)
            )
            self._compiled = None
            self.failed = True

    @property
    def active(self) -> bool:
        return self._compiled is not None

    def disable(self, reason: str = "") -> None:
        """Навсегда откатывается на eager до конца жизни движка."""
        if self._compiled is not None:
            print(
                "[Warning]: отключаю torch.compile для %s%s"
                % (self._name, (": " + reason) if reason else "")
            )
        self._compiled = None
        self.failed = True

    def __call__(self, *args, **kwargs):
        if self._compiled is None:
            return self._eager(*args, **kwargs)

        try:
            result = self._compiled(*args, **kwargs)
        except Exception as error:
            # Одна ошибка компилятора не должна ронять звук: уходим в eager.
            self.disable(str(error))
            try:
                if torch.cuda.is_available():
                    torch.cuda.synchronize()
            except Exception:
                pass
            return self._eager(*args, **kwargs)

        if self._clone_output and isinstance(result, torch.Tensor):
            # Память вывода CUDA-графа переиспользуется — забираем свою копию.
            return result.clone()
        return result


def frame(x: torch.Tensor, frame_length: int, hop_length: int, axis: int = -1):
    """
    Slice a tensor into overlapping frames using stride tricks.

    Args:
        x (torch.Tensor): Input tensor containing the signal data.
        frame_length (int): Number of samples in each frame.
        hop_length (int): Number of samples between consecutive frames.
        axis (int, optional): Axis along which framing is applied. Defaults to the last axis (-1).
    """

    if x.shape[axis] < frame_length or hop_length < 1:
        raise ValueError(
            "Target axis length must be >= frame_length and hop_length >= 1"
        )

    axis = axis % x.ndim
    if (
        axis != x.ndim - 1
    ):  # Move target axis to the last dimension for easier processing
        x = x.movedim(axis, -1)

    # Compute output shape and stride configuration
    size = x.shape[:-1] + (1 + (x.shape[-1] - frame_length) // hop_length, frame_length)
    stride = x.stride()[:-1] + (hop_length * x.stride()[-1], x.stride()[-1])

    xw = torch.as_strided(
        x, size=size, stride=stride
    )  # Create framed tensor without copying memory
    if axis != x.ndim - 1:  # Restore original axis order if needed
        xw = xw.movedim(-2, axis)

    return xw


def rms(
    y,
    frame_length: int = 2048,
    hop_length: int = 512,
    center: bool = True,
    pad_mode: str = "constant",
    dtype: torch.dtype = torch.float32,
    device: str = "cpu",
):
    """
    Compute the Root Mean Square (RMS) energy of an audio signal.

    Args:
        y (torch.Tensor or numpy.ndarray): Input audio signal.
        frame_length (int, optional): Length of each analysis frame. Defaults to 2048.
        hop_length (int, optional): Number of samples between frames. Defaults to 512.
        center (bool, optional): If True, pad the signal so frames are centered. Defaults to True.
        pad_mode (str, optional): Padding mode used when centering. Defaults to "constant".
        dtype (torch.dtype, optional): Tensor data type. Defaults to torch.float32.
        device (str, optional): Target device for computation. Defaults to "cpu".
    """

    # Convert input to tensor and move to target device/dtype
    y = (
        y.to(device=device, dtype=dtype)
        if torch.is_tensor(y)
        else torch.from_numpy(y.copy()).to(device=device, dtype=dtype)
    )

    if center:  # Pad signal so frames are centered
        y = torch.nn.functional.pad(
            y, (frame_length // 2, frame_length // 2), mode=pad_mode
        )

    x = frame(y, frame_length=frame_length, hop_length=hop_length)
    # Compute mean square energy per frame
    power = x.square().mean(dim=-1, keepdim=True)
    # Convert power to RMS
    result = power.sqrt().mT

    return result


class AudioProcessorTorch:
    """
    A class for processing audio signals, specifically for adjusting RMS levels.
    """

    def change_rms(
        source_audio: torch,
        source_rate: int,
        target_audio: torch,
        target_rate: int,
        rate: float,
        dtype=torch.float32,
        device="cpu",
    ):
        """
        Adjust the RMS level of target_audio to match the RMS of source_audio, with a given blending rate.

        Args:
            source_audio: The source audio signal as a Torch Tensor.
            source_rate: The sampling rate of the source audio.
            target_audio: The target audio signal to adjust.
            target_rate: The sampling rate of the target audio.
            rate: The blending rate between the source and target RMS levels.
            dtype (torch.dtype, optional): Tensor data type. Defaults to torch.float32.
            device (str, optional): Target device for computation. Defaults to "cpu".
        """
        if is_directml(device):
            # DirectML: rms() строит окна через as_strided (нестандартные шаги
            # памяти), а F.interpolate(mode="linear") реализован не полностью.
            # Огибающая короткая — считаем её на CPU и возвращаем на устройство.
            adjusted = AudioProcessorTorch.change_rms(
                source_audio.detach().float().cpu(),
                source_rate,
                target_audio.detach().float().cpu(),
                target_rate,
                rate,
                dtype=torch.float32,
                device="cpu",
            )
            return adjusted.to(device=target_audio.device, dtype=target_audio.dtype)

        # Calculate RMS of both audio data
        rms1 = rms(
            y=source_audio,
            frame_length=source_rate // 2 * 2,
            hop_length=source_rate // 2,
            device=device,
            dtype=dtype,
        )
        rms2 = rms(
            y=target_audio,
            frame_length=target_rate // 2 * 2,
            hop_length=target_rate // 2,
            device=device,
            dtype=dtype,
        )

        # Interpolate RMS to match target audio length
        rms1 = F.interpolate(
            rms1.unsqueeze(0),
            size=target_audio.shape[0],
            mode="linear",
        ).squeeze()
        rms2 = F.interpolate(
            rms2.unsqueeze(0),
            size=target_audio.shape[0],
            mode="linear",
        ).squeeze()
        rms2 = torch.maximum(rms2, torch.zeros_like(rms2) + 1e-6)

        # Adjust target audio RMS based on the source audio RMS
        adjusted_audio = target_audio * (
            torch.pow(rms1, 1 - rate) * torch.pow(rms2, rate - 1)
        )
        return adjusted_audio


class IndexWrapper:
    """
    A lightweight wrapper for loading, converting, and searching FAISS indexes
    using PyTorch tensors.

    Supports:
    - Reading a FAISS index
    - Converting vectors to tensors
    - Performing brute-force L2 distance search with PyTorch
    """

    def __init__(
        self,
        index_path: str,
        nprobe: int = 12,
        device: str = "cuda",
        dtype: torch.dtype = torch.float32,
        clamp: float = 1e-8,
    ):
        """
        Initialize the index wrapper.

        Args:
            index_path (str): Path to the FAISS index file.
            nprobe (int, optional): Number of IVF clusters to probe during search. Higher values improve accuracy but increase search time.
            device (str, optional): Target device for computation. Defaults to "cpu".
            dtype (torch.dtype, optional): Tensor data type. Defaults to torch.float32.
            clamp (float, optional): Minimum distance value used to avoid negative.
        """

        self.index_path = index_path
        self.nprobe = nprobe
        self.device = device
        self.dtype = dtype
        self.clamp = clamp
        self.faiss_cpu = False
        self.index = None
        self.big_npy = None
        self.b_norms = None
        self.big_tensor = None
        # Индекс считается готовым только после успешного чтения файла и
        # построения тензоров. Иначе search() обращался к None и падал.
        self.ready = False
        self.load_error = None

    def read_index(self):
        """
        Load a FAISS index and reconstruct all stored vectors.
        """

        self.load_error = None

        if self.index_path != "" and os.path.exists(self.index_path):
            try:
                index = faiss.read_index(self.index_path)
                big_npy = index.reconstruct_n(0, index.ntotal)
            except Exception as error:
                print(f"An error occurred reading the FAISS index: {error}")
                self.load_error = str(error)
                index = big_npy = None
        else:
            if self.index_path:
                self.load_error = f"index file not found: {self.index_path}"
            index = big_npy = None

        if index is not None:
            index.nprobe = self.nprobe
        self.index = index
        self.big_npy = big_npy

        return index, big_npy

    def read_index_tensor(self):
        """
        Load the FAISS index and convert reconstructed vectors into contiguous PyTorch tensors. Also precomputes squared norms for efficient L2 distance search.
        """

        self.read_index()

        if self.index is None or self.big_npy is None:
            self.big_tensor = None
            self.b_norms = None
            self.ready = False
        else:
            self.big_tensor = (
                torch.from_numpy(self.big_npy)
                .to(device=self.device, dtype=self.dtype)
                .contiguous()
            )
            # Precompute ||b||² for distance calculation
            self.b_norms = (self.big_tensor**2).sum(dim=-1, keepdim=True).T.contiguous()
            self.ready = True

        return self.big_tensor, self.b_norms

    def is_ready(self):
        """True, если индекс прочитан и пригоден для поиска."""

        return bool(self.ready and self.index is not None)

    def __bool__(self):
        # Пустая обёртка (нет файла .index или он не читается) должна быть
        # ложной: иначе вызывающий код считает индекс доступным и падает.
        return self.is_ready()

    def search(self, query, k=8):
        """
        Perform brute-force L2 nearest neighbor search using PyTorch.

        Args:
            query (torch.Tensor): Query tensor with shape [N, D].
            k (int, optional): Number of nearest neighbors to return.
        """

        if not self.is_ready():
            raise RuntimeError(
                "FAISS index is not loaded"
                + (f": {self.load_error}" if self.load_error else "")
            )

        with torch.inference_mode():
            if not self.faiss_cpu:
                try:
                    # Compute ||a||^2 for query vectors
                    q_norm = (query**2).sum(dim=-1, keepdim=True)
                    # Compute squared L2 distances
                    distances = (
                        torch.addmm(
                            self.b_norms, query, self.big_tensor.T, alpha=-2.0, beta=1.0
                        )
                        + q_norm
                    )
                    # Prevent negative values caused by floating-point precision
                    distances = distances.clamp(min=self.clamp)

                    # Retrieve smallest distances
                    scores, indices = torch.topk(-distances, k=k, dim=-1)

                    return -scores, indices
                except INDEX_SEARCH_ERRORS:
                    print(
                        "[Warning]: An error occurred when using Faiss with the GPU. Fallback to the CPU."
                    )

                    self.faiss_cpu = True
                    self.b_norms = None

                    empty_device_cache(self.device)
                    return self.search(query, k)
            else:
                npy = query.cpu().numpy()
                score, ix = self.index.search(npy, k)

                return (
                    torch.from_numpy(score).to(self.device).to(self.dtype),
                    torch.from_numpy(ix).to(self.device).long(),
                )
